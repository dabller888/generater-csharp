﻿namespace NVelocity.Extension
{
    /// <summary>
    /// 
    /// </summary>
    public class StringExtension
    {
        
    }
}
